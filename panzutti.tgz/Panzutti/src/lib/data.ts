import { supabase } from "./supabase";

export type MenuItem = {
  id: string;
  slug: string;
  name_en: string;
  name_ar: string;
  description_en: string | null;
  description_ar: string | null;
  price: number; // piasters
  image_url: string | null;
  is_signature: boolean;
  is_sold_out: boolean;
  addon_groups: { id: string; min_select: number }[];
};
export type MenuCategory = { id: string; slug: string; name_en: string; name_ar: string; items: MenuItem[] };

export type Branch = {
  id: string;
  slug: string;
  name_en: string;
  name_ar: string;
  address_en: string;
  address_ar: string;
  phone: string;
  opens_at: string;
  closes_at: string;
  timezone: string;
  accepts_delivery: boolean;
  accepts_pickup: boolean;
};

export type FamilyPhoto = { id: string; url: string; caption: string | null; uploader_name: string | null; is_official: boolean };

export type HomeData = {
  signature: MenuItem[];
  allItems: MenuItem[];
  branch: Branch;
  family: FamilyPhoto[];
  live: boolean; // false = Supabase not reachable, showing built-in content
};

const CDN = "https://res.cloudinary.com/fwyx4bzm/image/upload";

/** Shown if Supabase is not configured or not reachable, so the page never breaks. */
const FALLBACK_ITEMS: MenuItem[] = [
  { id: "f1", slug: "fried-truffle-buffalo-balls", name_en: "Fried Truffle Buffalo Balls", name_ar: "كرات جبنة بافلو مقلية بالترافل", description_en: "5 fried buffalo cheese balls with truffle mayo sauce, parmesan cheese and parsley.", description_ar: null, price: 14500, image_url: `${CDN}/v1784112206/panzutti/menu/Djdm5XM30k3CC4N5AYONL.webp`, is_signature: true, is_sold_out: false, addon_groups: [] },
  { id: "f2", slug: "hot-honey-pepperoni", name_en: "Hot Honey Pepperoni", name_ar: "هوت هوني بيبروني", description_en: "Mozzarella and pepperoni grilled to crispy perfection, finished with our signature hot honey sauce.", description_ar: null, price: 20500, image_url: `${CDN}/v1784113482/panzutti/menu/cjnN-7j5AUzV-yVSbYbi4.webp`, is_signature: true, is_sold_out: false, addon_groups: [] },
  { id: "f3", slug: "nutella-panuozzo", name_en: "Nutella Panuozzo", name_ar: "بانوتزو نوتيلا", description_en: "A freshly made cocoa-dough panuozzo filled generously with creamy Nutella.", description_ar: null, price: 18500, image_url: `${CDN}/v1784458184/panzutti/menu/7d04sYCoj9OKi2cIii5HN.png`, is_signature: true, is_sold_out: false, addon_groups: [] },
  { id: "f4", slug: "fizz-craft", name_en: "Fizz Craft", name_ar: "فيز كرافت", description_en: "Mixed berries meet peach in a sparkling citrus refresher.", description_ar: null, price: 17500, image_url: `${CDN}/v1784113621/panzutti/menu/IOwCDCfA8rRXGjVi8L73p.webp`, is_signature: true, is_sold_out: false, addon_groups: [] },
  { id: "f5", slug: "chicken-cream-alfredo", name_en: "Chicken Cream Alfredo", name_ar: "تشيكن كريم ألفريدو", description_en: "Grilled chicken breast, fresh rocca and parmesan with creamy alfredo mushroom sauce.", description_ar: null, price: 25000, image_url: `${CDN}/v1784112166/panzutti/menu/bY9F6pE8cY_u8RjorySmA.webp`, is_signature: false, is_sold_out: false, addon_groups: [] },
  { id: "f6", slug: "the-comfort", name_en: "The Comfort", name_ar: "ذا كومفورت", description_en: "Golden fried sourdough panuozzo with marinara, fresh mozzarella, basil and parmesan.", description_ar: null, price: 17900, image_url: `${CDN}/v1784113179/panzutti/menu/yDPyC2Rsy9eWWIOrw6d3T.webp`, is_signature: false, is_sold_out: false, addon_groups: [{ id: "side", min_select: 1 }] },
  { id: "f7", slug: "iconic-tiramisu", name_en: "Iconic Tiramisu", name_ar: "تيراميسو", description_en: "Rich mascarpone cream, coffee-soaked lady fingers and a cocoa finish.", description_ar: null, price: 29500, image_url: `${CDN}/v1784114596/panzutti/menu/yFvCzaQW6uKEdIRY2oyEp.webp`, is_signature: false, is_sold_out: false, addon_groups: [] },
  { id: "f8", slug: "kiwi-chiller", name_en: "Kiwi Chiller", name_ar: "كيوي تشيلر", description_en: "Fresh kiwi and mint blended into the ultimate refreshing chill.", description_ar: null, price: 17500, image_url: `${CDN}/v1784113789/panzutti/menu/-PI6QAugF2JjbYpOSxAHs.webp`, is_signature: false, is_sold_out: false, addon_groups: [] },
];

const FALLBACK_BRANCH: Branch = {
  id: "fallback",
  slug: "meraki-salah-salem",
  name_en: "Meraki Complex – Salah Salem",
  name_ar: "ميراكي كومبلكس – صلاح سالم",
  address_en: "Meraki Complex, Air Force House, El Golf, Salah Salem, Cairo",
  address_ar: "ميراكي كومبلكس، دار القوات الجوية، الجولف، صلاح سالم، القاهرة",
  phone: "+201041093713",
  opens_at: "09:00:00",
  closes_at: "02:00:00",
  timezone: "Africa/Cairo",
  accepts_delivery: true,
  accepts_pickup: true,
};

async function withTimeout<T>(p: PromiseLike<T>, ms = 4000): Promise<T> {
  return Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error("timeout")), ms))]);
}

export async function getHomeData(): Promise<HomeData> {
  const fallback: HomeData = {
    signature: FALLBACK_ITEMS.filter((i) => i.is_signature),
    allItems: FALLBACK_ITEMS,
    branch: FALLBACK_BRANCH,
    family: [],
    live: false,
  };
  if (!supabase) return fallback;

  try {
    const [menuRes, branchRes, galleryRes] = await withTimeout(
      Promise.all([
        supabase.rpc("get_menu"),
        supabase.from("branches").select("*").eq("is_active", true).order("created_at").limit(1).maybeSingle(),
        supabase.rpc("get_family_gallery", { p_limit: 8 }),
      ]),
    );
    if (menuRes.error) throw menuRes.error;

    const categories = (menuRes.data ?? []) as MenuCategory[];
    const allItems = categories.flatMap((c) => c.items ?? []);
    const signature = allItems.filter((i) => i.is_signature && !i.is_sold_out);

    // Approved Panzutti Family photos live in a private bucket -> short-lived signed URLs
    let family: FamilyPhoto[] = [];
    const rows = (galleryRes.data ?? []) as { id: string; file_path: string; caption: string | null; uploader_name: string | null; is_official: boolean }[];
    if (rows.length) {
      const { data: signed } = await supabase.storage
        .from("panzutti-family")
        .createSignedUrls(rows.map((r) => r.file_path), 60 * 60);
      family = rows
        .map((r, i) => ({ id: r.id, url: signed?.[i]?.signedUrl ?? "", caption: r.caption, uploader_name: r.uploader_name, is_official: r.is_official }))
        .filter((p) => p.url);
    }

    return {
      signature: signature.length ? signature : allItems.slice(0, 4),
      allItems,
      branch: (branchRes.data as Branch | null) ?? FALLBACK_BRANCH,
      family,
      live: true,
    };
  } catch (e) {
    console.warn("[home] Supabase unavailable, using built-in content:", (e as Error).message);
    return fallback;
  }
}

/** Is the branch open right now (Cairo time)? Handles closing after midnight. */
export function openStatus(b: Branch, now = new Date()) {
  const local = new Intl.DateTimeFormat("en-GB", { timeZone: b.timezone, hour: "2-digit", minute: "2-digit", hour12: false }).format(now);
  const toMin = (t: string) => {
    const [h, m] = t.split(":").map(Number);
    return (h % 24) * 60 + m;
  };
  const t = toMin(local), o = toMin(b.opens_at), c = toMin(b.closes_at);
  const open = o === c ? true : o < c ? t >= o && t < c : t >= o || t < c;
  return { open };
}
