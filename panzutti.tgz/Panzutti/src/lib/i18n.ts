export const locales = ["en", "ar"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "en";

export const isLocale = (v: string): v is Locale => (locales as readonly string[]).includes(v);
export const dirOf = (l: Locale) => (l === "ar" ? "rtl" : "ltr");

const en = {
  meta: {
    title: "Panzutti — The First Authentic Panuozzo in Egypt",
    description:
      "Neapolitan sourdough baked to order in our wood-fired oven. Order Panuozzo for delivery or pickup in Heliopolis. Fatto con amore.",
  },
  nav: { menu: "Menu", family: "Panzutti Family", about: "Our story", careers: "Join our team", visit: "Visit us", order: "Order now", language: "العربية" },
  hero: {
    kicker: "The first authentic Panuozzo in Egypt",
    titleTop: "Your Next",
    titleScript: "Favorite Bite.",
    subtitle: "Neapolitan sourdough, baked to order in our wood-fired oven and filled right in front of you.",
    orderNow: "Order now",
    explore: "Explore the menu",
    sticker: "Panuozzo\nand more",
    open: "Open now",
    closed: "Closed now",
    until: "until",
    opensAt: "opens at",
    perks: ["Wood-fired, baked to order", "Delivery & pickup", "Cash or InstaPay"],
  },
  bestsellers: { kicker: "Signature stars", title: "The ones everyone comes back for", viewAll: "Full menu", add: "Add", signature: "Signature", soldOut: "Sold out", empty: "Our bestsellers will appear here soon." },
  story: {
    kicker: "Our story",
    titleA: "Egyptian heart.",
    titleB: "Italian dough.",
    body: "We took the pizza dough everyone already loves and reimagined it as a modern, handheld Panuozzo. Every one is sourdough, baked in our wood-fired oven only when you order it, and filled live — Italian inspiration, made على إيدك.",
    steps: [
      { t: "Sourdough", d: "Slow-rested Neapolitan dough" },
      { t: "Wood-fired", d: "Baked only when you order" },
      { t: "Filled live", d: "Right in front of you" },
    ],
    cta: "Taste the story",
    caption: "fresh from the oven",
    badge: "made to order",
  },
  how: {
    kicker: "Hot to you, your way",
    title: "How to order",
    items: [
      { t: "Delivery", d: "Hot to your door across Heliopolis and Nasr City. Track it live from the oven to you." },
      { t: "Pickup", d: "Order ahead, skip the line and collect it hot at Meraki Complex." },
      { t: "Pay your way", d: "Cash on delivery, or InstaPay — just upload the transfer screenshot at checkout." },
    ],
    cta: "Start your order",
  },
  family: {
    kicker: "Panzutti Family",
    title: "Your moments, our oven",
    body: "Birthdays, first dates, late-night cravings — share your Panzutti moments. Every photo is reviewed before it joins the family wall.",
    share: "Share your photo",
    see: "See the family wall",
    empty: "Be the first to join the wall",
  },
  join: {
    title: "Grow with Panzutti",
    body: "We're always looking for passionate people and great suppliers.",
    team: "Join our team",
    teamD: "Cashiers, baristas, kitchen crew and more",
    supplier: "Become a supplier",
    supplierD: "Fresh produce, dairy, packaging, services",
  },
  visit: {
    kicker: "Come say ciao",
    title: "Visit us",
    hours: "Hours",
    daily: "Daily",
    directions: "Get directions",
    call: "Call us",
  },
  footer: { tagline: "Fatto con amore ❤", rights: "All rights reserved.", follow: "Follow us" },
  currency: "EGP",
};

const ar: typeof en = {
  meta: {
    title: "بانزوتي — أول بانوتزو أصلي في مصر",
    description: "عجينة نابوليتانية مخمّرة بتتخبز عند الطلب في فرن الحطب. اطلب بانوتزو دليفري أو استلام من مصر الجديدة.",
  },
  nav: { menu: "المنيو", family: "عيلة بانزوتي", about: "حكايتنا", careers: "انضم لفريقنا", visit: "زورنا", order: "اطلب دلوقتي", language: "English" },
  hero: {
    kicker: "أول بانوتزو أصلي في مصر",
    titleTop: "أكلتك المفضلة",
    titleScript: "الجاية.",
    subtitle: "عجينة نابوليتانية مخمّرة، بتتخبز عند الطلب في فرن الحطب وبتتحشي قدامك.",
    orderNow: "اطلب دلوقتي",
    explore: "شوف المنيو",
    sticker: "بانوتزو\nوأكتر",
    open: "مفتوح دلوقتي",
    closed: "مقفول دلوقتي",
    until: "لحد",
    opensAt: "بيفتح الساعة",
    perks: ["فرن حطب وبيتخبز عند الطلب", "دليفري واستلام", "كاش أو إنستاباي"],
  },
  bestsellers: { kicker: "النجوم", title: "اللي الكل بيرجعلها", viewAll: "المنيو كله", add: "أضف", signature: "مميز", soldOut: "خلصان", empty: "الأكثر مبيعاً هتظهر هنا قريب." },
  story: {
    kicker: "حكايتنا",
    titleA: "قلب مصري.",
    titleB: "عجينة إيطالي.",
    body: "أخدنا عجينة البيتزا اللي الكل بيحبها وعملناها بانوتزو عصري تمسكه في إيدك. كل واحد عجينة مخمّرة، بيتخبز في فرن الحطب لما تطلبه بس، وبيتحشي قدامك — إلهام إيطالي، معمول على إيدك.",
    steps: [
      { t: "عجينة مخمّرة", d: "عجينة نابوليتانية بتريّح على مهلها" },
      { t: "فرن حطب", d: "بتتخبز لما تطلب بس" },
      { t: "بتتحشي قدامك", d: "طازة ومن غير استنى" },
    ],
    cta: "دوق الحكاية",
    caption: "طازة من الفرن",
    badge: "عند الطلب",
  },
  how: {
    kicker: "سخن وعلى مزاجك",
    title: "إزاي تطلب",
    items: [
      { t: "دليفري", d: "سخن لحد باب بيتك في مصر الجديدة ومدينة نصر. وتابع طلبك لحظة بلحظة." },
      { t: "استلام", d: "اطلب بدري، ومن غير طابور استلمه سخن من ميراكي كومبلكس." },
      { t: "ادفع زي ما تحب", d: "كاش عند الاستلام، أو إنستاباي — ارفع صورة التحويل وقت الطلب." },
    ],
    cta: "ابدأ طلبك",
  },
  family: {
    kicker: "عيلة بانزوتي",
    title: "لحظاتكم، من فرننا",
    body: "أعياد ميلاد، خروجات، جوع آخر الليل — شاركنا لحظاتك في بانزوتي. كل صورة بتتراجع قبل ما تنضم لحيطة العيلة.",
    share: "شارك صورتك",
    see: "شوف حيطة العيلة",
    empty: "كن أول واحد على الحيطة",
  },
  join: {
    title: "اكبر مع بانزوتي",
    body: "دايماً بندور على ناس شغوفة وموردين مميزين.",
    team: "انضم لفريقنا",
    teamD: "كاشير، باريستا، مطبخ وغيرهم",
    supplier: "كن مورد معانا",
    supplierD: "خضار وفاكهة، ألبان، تغليف، خدمات",
  },
  visit: {
    kicker: "تعالى قول تشاو",
    title: "زورنا",
    hours: "مواعيد العمل",
    daily: "يومياً",
    directions: "الاتجاهات",
    call: "اتصل بينا",
  },
  footer: { tagline: "Fatto con amore ❤", rights: "جميع الحقوق محفوظة.", follow: "تابعنا" },
  currency: "ج.م",
};

const dictionaries = { en, ar };
export type Dictionary = typeof en;
export const getDictionary = (l: Locale): Dictionary => dictionaries[l];
