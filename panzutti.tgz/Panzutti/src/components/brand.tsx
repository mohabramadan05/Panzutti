/* eslint-disable @next/next/no-img-element -- logo/mascot are transparent PNGs of unknown size */
import { brand } from "@/lib/brand";
import { cn } from "@/lib/utils";

export function Logo({ variant = "red", className }: { variant?: "red" | "cream"; className?: string }) {
  return (
    <img
      src={variant === "red" ? brand.logoRed : brand.logoCream}
      alt="Panzutti — Panuozzo & More"
      className={cn("h-10 w-auto object-contain", className)}
    />
  );
}

export function Mascot({ className }: { className?: string }) {
  return (
    <img
      src={brand.mascot}
      alt=""
      aria-hidden
      draggable={false}
      loading="lazy"
      className={cn("block select-none object-contain", className)}
    />
  );
}

export function SectionTitle({
  kicker,
  title,
  className,
  light,
}: {
  kicker?: string;
  title: string;
  className?: string;
  light?: boolean;
}) {
  return (
    <div className={cn("mb-8", className)}>
      {kicker && (
        <p className={cn("mb-2 text-sm font-bold uppercase tracking-[0.2em]", light ? "text-brand-yellow" : "text-brand-red")}>
          {kicker}
        </p>
      )}
      <h2 className={cn("text-4xl md:text-5xl", light ? "text-brand-cream" : "text-primary")}>{title}</h2>
    </div>
  );
}
